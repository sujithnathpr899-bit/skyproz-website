# Contract Finder Deployment

The Skyproz company website remains a static Netlify site. Contract Finder is a separate application because accounts, a contract database, alerts, scheduled imports, administrator tools, and AI features require a continuously running backend with persistent storage.

## Deliverables

- `skyproz-website.zip`: updated company website with Contract Finder navigation.
- `contract-finder-platform.zip`: complete Node.js backend, frontend, database migrations, APIs, jobs, tests, Docker configuration, and technical documentation.

## Safe Publishing Order

1. Deploy `contract-finder-platform.zip` to a persistent Node 24 or Docker host with a persistent disk.
2. Configure the environment variables from `.env.example`.
3. Run `node scripts/migrate.mjs` and `node scripts/seed.mjs` only for initial setup.
4. Replace or delete all demo accounts and demonstration contracts.
5. Configure HTTPS and verify `/api/contract-finder/health`.
6. Proxy both `/contract-finder/*` and `/api/contract-finder/*` from `skyproz.in` to the backend service.
7. Schedule `node scripts/run-jobs.mjs` daily.
8. Upload `skyproz-website.zip` to the existing Netlify site only after the proxy works.

## Optional Services

- Email alerts require a Resend API key.
- WhatsApp premium alerts require Meta WhatsApp Cloud API credentials.
- Provider-generated AI analysis requires an AI endpoint, API key, and model name. Without these, the module returns clearly labelled local fallback guidance.

See the included `README.md` for commands, demo credentials, source mapping, security settings, and API details.
